"""
02/09/26
This my first program in python, learning basics via mini projs


The Spec-
1. Ask the user to type in a number — this will be the upper limit of the range.
2. Validate the input:
    If it's not a valid number, tell them and ask again (don't crash).
    If it's 0 or negative, tell them it must be greater than 0, and stop the program.
3. Once you have a valid upper limit, generate a random number between 0 and that limit.
4. Let the user guess repeatedly:
    If their guess is too high, tell them.
    If their guess is too low, tell them.
    If they get it right, congratulate them and stop asking.
5. Keep count of how many guesses it took.
6. At the end, print the total number of guesses.

Constraints to push yourself
Don't use any code I've written before — build the logic yourself from this description.
You'll need: import random, some kind of loop, input(), and comparison logic.
Think about: what happens if they type "five" instead of 5? What happens if they type a number way outside the range?


Difficulty Levels — Spec
Instead of asking the user to type in a max limit number, ask them to choose a difficulty: Easy, Medium, or Hard.
Each difficulty maps to a preset limit — you decide the exact numbers, but something like:
Easy → limit of 10
Medium → limit of 50
Hard → limit of 100
Validate their difficulty choice the same way you've validated everything else — if they type something that isn't one of the three valid options, tell them and ask again (don't crash, don't silently continue).
Once you have a valid difficulty, set lim to the matching preset number, and continue into the rest of the game exactly as before (generate target, run the guessing loop).

Guess Cap — Spec
Set a maximum number of guesses allowed — e.g. MAX_GUESSES = 5 (you can tie this to difficulty later if you want, but keep it simple/fixed for now).
In your guessing loop, track how many guesses they've used (you already have a doing this).
If they run out of guesses without getting it right, the loop should stop, reveal the correct answer, and not let them keep guessing.
If they guess correctly before running out, everything works exactly as before (no change to that path).


"""
# NUMBER GUESSING GAME 

import random
import sys

def game():
    print("Game has started")
    while True:
        difficulty=input("\nChoose a difficulty [1.EASY / 2.MEDIUM / 3.HARD]\nPress 1 for Easy\nPress 2 for Medium\nPress 3 for Hard.\nDifficulty: ")  
        max_guesses=0
        if difficulty.isdigit():
            difficulty=int(difficulty)
            if difficulty<=0:
                print("Enter valid difficulty.")

            elif difficulty==1:
                difficulty=2
                max_guesses=3
                break
            elif difficulty==2:
                difficulty=5
                max_guesses=6
                break
            elif difficulty==3:
                difficulty=10
                max_guesses=11
                break

            else:
                print("Enter valid difficulty level.")
        else:
            print("Enter valid integer.")
    target=random.randint(0,difficulty)
    guess_count=0
    while True:
        guess=input("\nEnter a guess: ")     
        if guess.isdigit():
            guess=int(guess) 
            guess_count+=1

            if guess==target:

                print("Your guess is correct")
                print("It took you",guess_count,"/",max_guesses,"tries to guess the number")
                break
            elif guess_count==max_guesses:
                print("Total number of guesses",max_guesses,"reached. You Lose.")
                sys.exit()
            elif guess>target:

                print("Your guess was higher than the target")
                print("Number of guesses",guess_count,"/",max_guesses)
            elif guess<target:

                print("Your guess was lower than the target")
                print("Number of guesses",guess_count,"/",max_guesses)
            
        else:
            print("Enter valid integer.")
        
            
            
print("--Number Guessing Game--")
while True:
    choice=input("\nDo you want to play (Y/N)\nEnter Y for yes and N for no\nInput= ")
    if choice.lower()=="y":
        
        print("Game Start")
        game()
        while True:
            
            choice2=input("\nDo you want to play again (Y/N)\nEnter Y for yes and N for no\nInput= ")
            if choice2.lower()=="y":
                game()
            
            elif choice2.lower()=="n":
                print("--Game exit--")
                sys.exit()
            else:#error? invalid response like 'maybe'
                print("\nInvalid input, please enter 'Y' or 'N' to start the game again \n Input: ")
        
    elif choice.lower()=="n":
        print("--Game exit--")
        break
    else:#error? invalid response like 'maybe'
        print("\nInvalid input, please enter 'Y' or 'N' to start the game.\n Input: ")
